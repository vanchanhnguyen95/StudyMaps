## 2.0.20221001

* 510/NQ-UBTVQH15: Nghị quyết thành lập thị trấn Phương Sơn thuộc huyện Lục Nam và thị trấn Bắc Lý thuộc huyện Hiệp Hòa, tỉnh Bắc Giang;
* 569/NQ-UBTVQH15: Nghị quyết về việc thành lập thị trấn Bình Phú thuộc huyện Cai Lậy, tỉnh Tiền Giang;
* 570/NQ-UBTVQH15: Nghị quyết về việc thành lập thị xã Chơn Thành và các phường thuộc thị xã Chơn Thành, tỉnh Bình Phước;

## 2.0.20220410

* 469/NQ-UBTVQH15: Nghị quyết về việc thành lập các phường thuộc thị xã Phổ Yên và thành lập thành phố Phổ Yên, tỉnh Thái Nguyên;

## 2.0.20211101

* Migrate to null safety (#23, authored by @definev)

## 1.3.20211101

* 387/NQ-UBTVQH15: Thành lập thành phố Từ Sơn thuộc tỉnh Bắc Ninh;

## 1.3.20210701

* 1260/NQ-UBTVQH14: Thành lập thị trấn Quý Lộc và thị trấn Yên Lâm thuộc huyện Yên Định, tỉnh Thanh Hóa;
* 1261/NQ-UBTVQH14: Thành lập thị trân Long Giao thuộc huyện Cẩm Mỹ, tỉnh Đồng Nai;
* 1262/NQ-UBTVQH14: Điều chỉnh địa giới hành chính cấp huyện, cấp xã và thành lập các thị trấn thuộc tỉnh Tuyên Quang;

## 1.3.20210201

* 1189/NQ-UBTVQH14: Thành lập phường Quỳnh Lâm và phường Trung Minh thuộc thành phố Hòa Bình, tỉnh Hòa Bình;
* 1188/NQ-UBTVQH14: thành lập thị trấn Cát Tiến thuộc huyện Phù Cát, tỉnh Bình Định;
* 1191/NQ-UBTVQH14: thành lập các phường thuộc thị xã Từ Sơn, tỉnh Bắc Ninh;
* 1107/NQ-UBTVQH14: Thành lập thị trấn Vĩnh Thanh Trung thuộc huyện Châu Phú, thị trấn Cô Tô thuộc huyện Tri Tôn và thị trấn Vĩnh Bình thuộc huyện Châu Thành, tỉnh An Giang;
* 1110/NQ-UBTVQH14: thành lập thị trấn Tân Bình thuộc huyện Bắc Tân Uyên, tỉnh Bình Dương;
* 1107/NQ-UBTVQH14: Thành lập thị trấn Vĩnh Thạnh Trung thuộc huyện Châu Phú, thị trấn Cô Tô thuộc huyện Tri Tôn và thị trấn Vĩnh Bình thuộc huyện Châu Thành, tỉnh An Giang;
* 1108/NQ-UBTVQH14: Thành lập các phường thuộc thành phố Thanh Hóa, tỉnh Thanh Hóa;
* 1111/NQ-UBTVQH14: Sắp xếp các đơn vị hành chính cấp huyện, cấp xã và thành lập thành phố Thủ Đức thuộc Thành phố Hồ Chí Minh;
* 1109/NQ-UBTVQH14: Thành lập thành phố Phú Quốc và các phường thuộc thành phố Phú Quốc, tỉnh Kiên Giang;
* 1003/NQ-UBTVQH14: thành lập phường An Bình A, phường An Bình B thuộc thị xã Hồng Ngự và thành phố Hồng Ngự thuộc tỉnh Đồng Tháp;

## 1.3.20200601

* First version
